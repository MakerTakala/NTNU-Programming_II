#pragma once

int mymatch(char *** , const char *, const char *);