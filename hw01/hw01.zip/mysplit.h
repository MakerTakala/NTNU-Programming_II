#pragma once

int mystrsplit( char *** , int * , const char *, const char * );