#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "mid_helper.h"

int main() {


    return 0;
}