# MIDTERM 41047025S 王重鈞

Use "make" to compile all program file

## 1 Bible
---


## 2 SRT Player
---


## 3 Circular Focus
---


## 4 BMP with 16 bits
---


## 5 Sliding Puzzle
---

