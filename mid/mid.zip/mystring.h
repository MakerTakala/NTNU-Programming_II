#pragma once

#include "mystring.h"

char *mystrtok_r(char *str, const char *delim , char **saveptr);