#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include "mid_helper.h"

int main() {
    FILE *in_file = open_file( "Please enter the file name: ", "r", 4096);
    FILE *out_file = NULL;
    if( ( out_file = fopen( "output.bmp", "w" ) ) == NULL ) {
        printf( "File could not be opened!\n" );
        exit(0);
    }
    double angle = ask_angle();
    angle = angle / 180 * M_PI;
    
    BmpHeader header;
    fread( &header, 54, 1, in_file );
    if( strncmp( header.bm, "BM", 2 ) || header.bpp != 24 ) {
        printf("Wrong file format!\n");
        exit(0);
    }
    
    uint32_t original_width = header.width, original_height = header.height;
    uint32_t new_width = 0, new_height = 0;
    count_width_height( original_width, original_height, angle, &new_width, &new_height );
    header.width = new_width;
    header.height = new_height;
    header.size = 54 + ( 24 * header.width + 31 ) / 32 * 4;
    header.bitmap_size = ( 24 * header.width + 31 ) / 32 * 4;
    fwrite( &header, 54, 1, out_file );

    printf("!!!width :%u height: %u\n", new_width, new_height);

    uint64_t pixel_size = 3 * new_width * new_height + 300;
    uint8_t pixels[pixel_size];
    memset( pixels, 0xFF, pixel_size );

    int32_t in_center_x = ( original_width - 1 ) / 2, in_center_y = ( original_height - 1 ) / 2;
    int32_t out_center_x = ( new_width - 1 ) / 2, out_center_y = ( new_height - 1 ) / 2;
    printf("%d, %d, %d, %d\n", in_center_x, in_center_y, out_center_x, out_center_y);

    for( int i = 0; i < new_height; i++ ) {
        for( int j = 0; j < new_width; j++ ) {
            uint8_t BGR_pixel[3] = {0};
            fread( &BGR_pixel, 3, 1, in_file );
            int32_t x = i - in_center_x, y = j - in_center_y;
            printf("%d, %d  ",x, y);
            x = x * cos(angle) - y * sin(angle) + out_center_x;
            y = x * sin(angle) + y * cos(angle) + out_center_y;
            printf("%d, %d\n",x, y);
            if( x < 0 || new_width <= x || y < 0 || new_height <= y ) {
                pixels[ 3 * ( new_width * y + x ) + 0 ] = BGR_pixel[0];
                pixels[ 3 * ( new_width * y + x ) + 1 ] = BGR_pixel[1];
                pixels[ 3 * ( new_width * y + x ) + 2 ] = BGR_pixel[2];
            }
        }
    }

    fwrite( &pixels, pixel_size, 1, out_file );

    fclose(in_file);
    fclose(out_file);

    return 0;
}