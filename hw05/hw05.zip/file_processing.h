#pragma once

FILE *open_file( char name[], char permission[] );