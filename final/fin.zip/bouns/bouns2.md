## Bouns2

Usually following the stream simultaneously. And I prefer Youtube, beacuse if I have quesion, I can watch video again.